#!/usr/bin/env python3
# AURORA DUAL-VOLTAGE MACHINE CODE v0.1
# H channel: 5.0 V -> logical weight 1
# M channel: 2.5 V -> logical weight 2
# Both channels remain electrically separate.
# Decoder value = H_state*1 + M_state*2

V_HIGH = 5.0
V_MID = 2.5

def encode(value):
    if value not in (0, 1, 2, 3):
        raise ValueError("Value must be 0, 1, 2, or 3.")
    return {
        "H": V_HIGH if value & 1 else 0.0,
        "M": V_MID if value & 2 else 0.0
    }

def decode(h_voltage, m_voltage, tolerance=0.25):
    h_ok = abs(h_voltage) <= tolerance or abs(h_voltage-V_HIGH) <= tolerance
    m_ok = abs(m_voltage) <= tolerance or abs(m_voltage-V_MID) <= tolerance
    if not (h_ok and m_ok):
        raise ValueError("Invalid voltage level.")
    h = 1 if abs(h_voltage-V_HIGH) <= tolerance else 0
    m = 2 if abs(m_voltage-V_MID) <= tolerance else 0
    return h + m

if __name__ == "__main__":
    print("AURORA DUAL-VOLTAGE MACHINE CODE")
    print("H=5V -> 1, M=2.5V -> 2")
    print("0:", encode(0))
    print("1:", encode(1))
    print("2:", encode(2))
    print("3:", encode(3))
    print("5V + 2.5V channels =>", decode(5.0, 2.5), "(digital value 3)")
