AURORA DUAL-VOLTAGE MACHINE CODE v0.1

Core idea:
H channel: 5.0 V -> logical weight 1
M channel: 2.5 V -> logical weight 2

The decoder computes:
VALUE = H_state*1 + M_state*2

Truth table:
H=0,   M=0     -> 0
H=5V,  M=0     -> 1
H=0,   M=2.5V  -> 2
H=5V,  M=2.5V  -> 3

Thus the combined digital state is 1+2=3.
The physical voltages are NOT added together and must not be
connected together. This is a two-channel digital encoding.

Hardware caution:
Do not feed 5 V into a GPIO that is not 5-V tolerant. Many modern
microcontrollers use 3.3-V logic. Real hardware needs suitable
level shifting/comparators and protection.

This package is a logic simulation, not a finished hardware design.
