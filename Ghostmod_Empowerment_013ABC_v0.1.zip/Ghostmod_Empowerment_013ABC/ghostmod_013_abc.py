#!/usr/bin/env python3
"""Ghostmod Empowerment 013 ABC — dependency-free state machine."""
STATES={"A":("0","OBSERVE"),"B":("1","CREATE"),"C":("3","VERIFY")}

def run(seq):
    out=[]
    for s in seq.upper():
        if s not in STATES: raise ValueError(f"Invalid symbol: {s}")
        code,action=STATES[s]; out.append((s,code,action))
    return out

if __name__ == '__main__':
    seq='ABC'
    print('GHOSTMOD EMPOWERMENT — 013 ABC')
    for s,c,a in run(seq): print(f'{s} -> {c} -> {a}')
    print('SMOKE TEST: PASS')
