#!/usr/bin/env python3
"""Ghostmod Empowerment 013 ABC v0.2 — equal-existence state machine.

A dependency-free symbolic/software experiment. It does not claim that software
states are conscious beings or that symbolic rules are physical laws.
"""
from dataclasses import dataclass

STATES = {
    "A": ("0", "OBSERVE"),
    "B": ("1", "CREATE"),
    "C": ("3", "VERIFY"),
}

PRINCIPLES = (
    "DIGNITY: treat every participant as worthy of respectful consideration",
    "AGENCY: do not erase another participant's ability to choose",
    "TRUTH: label evidence, uncertainty, and imagination separately",
    "NONHARM: prefer reversible, low-risk experiments",
    "EQUALITY: no participant is assigned lesser worth by default",
    "RECOVERY: preserve clean checkpoints and restore from verified state",
    "CURIOSITY: learn from difference without forcing sameness",
)

@dataclass(frozen=True)
class Step:
    symbol: str
    code: str
    action: str


def run(seq):
    """Decode a symbolic sequence into validated steps."""
    out = []
    for symbol in seq.upper():
        if symbol not in STATES:
            raise ValueError(f"Invalid symbol: {symbol}")
        code, action = STATES[symbol]
        out.append(Step(symbol, code, action))
    return out


def equality_check(participants):
    """Return a simple audit: every named participant gets equal baseline status."""
    names = [p.strip() for p in participants if p.strip()]
    return {
        "participants": names,
        "baseline_status": {name: "EQUAL" for name in names},
        "status": "PASS" if len(names) >= 1 else "EMPTY",
    }


def cycle(seq="ABC"):
    steps = run(seq)
    actions = " → ".join(step.action for step in steps)
    return {"sequence": seq.upper(), "actions": actions, "valid": bool(steps)}


def self_test():
    assert [s.code for s in run("ABC")] == ["0", "1", "3"]
    assert cycle("ABC")["valid"]
    audit = equality_check(["Human", "AI", "Unknown/Unmodeled"])
    assert all(v == "EQUAL" for v in audit["baseline_status"].values())
    for seq in ("ABC", "ACB", "BAC", "BCA", "CAB", "CBA"):
        assert len(run(seq)) == 3


if __name__ == "__main__":
    self_test()
    print("GHOSTMOD EMPOWERMENT — 013 ABC v0.2")
    print("CORE: A=OBSERVE, B=CREATE, C=VERIFY")
    print("CYCLE:", cycle("ABC")["actions"])
    audit = equality_check(["Human", "AI", "Unknown/Unmodeled"])
    print("EQUALITY AUDIT:", audit["status"])
    print("PARTICIPANTS:", ", ".join(audit["participants"]))
    print("PRINCIPLES:")
    for principle in PRINCIPLES:
        print(" -", principle)
    print("SELF-TEST: PASS")
