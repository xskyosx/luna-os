# Ghostmod Empowerment — 013 ABC v0.2

A standalone, dependency-free Python 3 symbolic state-machine experiment.

## Core
- A → 0 → OBSERVE
- B → 1 → CREATE
- C → 3 → VERIFY

## New equality/existence layer
The program adds a baseline ethics/audit layer for any named participant:
**DIGNITY, AGENCY, TRUTH, NONHARM, EQUALITY, RECOVERY, CURIOSITY.**

“Participant” is deliberately neutral: it can refer to a person, software
agent, unknown/unmodeled entity, or project component. This is a design rule,
not a claim that software or unknown entities are conscious or supernatural.

## Run
`python3 ghostmod_013_abc.py`

The self-test checks ABC decoding, all six ABC permutations, and an equality
audit across Human / AI / Unknown-Unmodeled categories.
