LUNA OS First Light Unified Memory Engine v0.2

Run on Termux: python luna_memory.py
Run on Alpine/Linux: python3 luna_memory.py

Folders:
  memories/          editable JSON memory records
  transcripts/       readable transcript text views
  imports/inbox/     place exports here before importing (optional)
  imports/originals/ byte-for-byte copies of source export files
  imports/manifests/ provenance, counts, and hashes for each import
  backups/           ZIP backups

ChatGPT export import:
1. Request/download your ChatGPT data export through ChatGPT's official Data Controls.
2. Extract the downloaded archive on your device.
3. Locate conversations.json. Copy it into imports/inbox/ or enter its full path in option 12.
4. Select option 12 and type IMPORT only after reviewing the source path and count.
5. Check option 8 and the manifest under imports/manifests/.

Safety and limits:
- This program does not log into ChatGPT, fetch your account data, or upload anything.
- The original conversations.json is copied byte-for-byte and hashed. Readable .txt files are derivatives.
- Media payloads may not be represented in the text views; retain the original export and its other files.
- Exact same export file hashes are detected to avoid repeat imports. Existing transcript filenames are never overwritten.
- Keep three copies of the entire project folder, including imports/originals and backups.
- Review imported files before sharing them; they may contain private information.
- Standard library only; no third-party packages required.
