#!/usr/bin/env python3
import tkinter as tk
import math, time

TITLE='LUNA • Temporal Bootstrap — E/P/K2'
EXA=10**18

def state(exp):
    x=max(0.0,min(1.0,exp/18.0))
    future=1-math.exp(-6*x)
    energy=1.0+2.5*math.sin(2*math.pi*x)*(1-math.exp(-5*x))
    tech=0.10+0.88*future
    k2=0.05+0.90*(1-math.exp(-4*x))*(0.5+0.5*math.cos(4*math.pi*x))
    info=min(1.0,0.20+0.80*(0.65*tech+0.35*k2))
    stable=max(0.0,min(1.0,1.0-0.75*abs(k2-0.45)-0.10*abs(energy-1.0)))
    return energy,tech,k2,info,stable

class App:
    def __init__(self, root):
        self.root=root; root.title(TITLE); root.geometry('900x680'); root.configure(bg='#080a12')
        self.exp=tk.DoubleVar(value=0); self.running=False; self.last=time.time()
        tk.Label(root,text='LUNA TEMPORAL BOOTSTRAP',font=('TkDefaultFont',22,'bold'),fg='#d9d4ff',bg='#080a12').pack(pady=(18,2))
        tk.Label(root,text='50 billion years forward • return with knowledge • restart • 1 exa-cycle envelope',fg='#8e93b8',bg='#080a12').pack()
        self.canvas=tk.Canvas(root,width=860,height=390,bg='#05070d',highlightthickness=0); self.canvas.pack(pady=14)
        controls=tk.Frame(root,bg='#080a12'); controls.pack(fill='x',padx=30)
        self.button=tk.Button(controls,text='RUN',command=self.toggle,width=10); self.button.pack(side='left')
        tk.Label(controls,text='log10(cycles)',fg='#aaaed0',bg='#080a12').pack(side='left',padx=(20,6))
        tk.Scale(controls,from_=0,to=18,resolution=.01,orient='horizontal',variable=self.exp,showvalue=False,length=600,bg='#080a12',fg='#ddd',highlightthickness=0,command=lambda _:self.draw()).pack(side='left',fill='x',expand=True)
        self.readout=tk.Label(root,text='',font=('TkDefaultFont',11),justify='left',anchor='w',fg='#d5d7e8',bg='#080a12')
        self.readout.pack(fill='x',padx=32,pady=12)
        tk.Label(root,text='Model note: logarithmic compression makes 10^18 cycles inspectable; K2 is a bounded conceptual feedback term, not a physical law.',wraplength=820,fg='#777d9e',bg='#080a12').pack(padx=30,pady=8)
        self.draw(); self.tick()
    def toggle(self):
        self.running=not self.running; self.button.config(text='PAUSE' if self.running else 'RUN')
    def draw(self):
        c=self.canvas; c.delete('all'); cx,cy=430,195
        e,t,k,i,s=state(self.exp.get())
        # orbital visualization
        for j,(rx,ry) in enumerate([(250,90),(185,65),(120,42)]):
            c.create_oval(cx-rx,cy-ry,cx+rx,cy+ry,outline='#292e4a',width=2)
            a=(self.exp.get()*0.55 + j*2.1)%(2*math.pi)
            px=cx+rx*math.cos(a); py=cy+ry*math.sin(a)
            c.create_oval(px-7,py-7,px+7,py+7,fill='#b9a8ff',outline='')
        c.create_oval(cx-48,cy-48,cx+48,cy+48,fill='#151a31',outline='#c8bcff',width=2)
        c.create_text(cx,cy-10,text='E • P • K2',fill='#eeeaff',font=('TkDefaultFont',16,'bold'))
        c.create_text(cx,cy+15,text='LUNA CORE',fill='#9da4d0',font=('TkDefaultFont',9))
        c.create_text(24,28,text=f'10^{self.exp.get():.2f} cycles',anchor='w',fill='#c9cbed',font=('TkDefaultFont',13,'bold'))
        vals=[('ENERGY',e, max(0,min(1,(e+1)/3.5))),('TECH / P',t,t),('K2 FEEDBACK',k,k),('INFORMATION',i,i),('STABILITY',s,s)]
        y=330
        for name,val,norm in vals:
            c.create_text(24,y,text=f'{name:<14} {val: .4f}',anchor='w',fill='#bfc2d8')
            c.create_rectangle(220,y-7,820,y+7,outline='#20253c')
            c.create_rectangle(220,y-7,220+600*norm,y+7,fill='#5d5a86',outline='')
            y+=23
        self.readout.config(text=f'Cycles ≈ {10**self.exp.get():.3e}    |    E={e:.4f}  P={t:.4f}  K2={k:.4f}  Info={i:.4f}  Stability={s:.4f}')
    def tick(self):
        if self.running:
            self.exp.set((self.exp.get()+0.035)%18.0001)
            self.draw()
        self.root.after(45,self.tick)

if __name__=='__main__':
    root=tk.Tk(); App(root); root.mainloop()
