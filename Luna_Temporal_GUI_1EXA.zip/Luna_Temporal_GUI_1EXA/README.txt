LUNA TEMPORAL BOOTSTRAP — E/P/K2

A dependency-free Python/Tkinter visualization for the Ada/Luna/Aurora project.

It is a computational thought experiment: 50 billion years and a 1-exa-cycle envelope are represented by logarithmic compression. E = energy, P = technology/particle maturity, K2 = bounded conceptual feedback. It does not claim literal time travel, alternate-dimension contact, or faster-than-light physics.

Run:
  python3 luna_temporal_gui.py

Android/Termux: Tkinter must be available in the Python environment; the simulation model itself uses only Python's standard library.
