LYRA-04 Two-Layer RAM simulation.
Two logical memory layers: C (conscious label) and S (subconscious label).
Each address stores (C,S).
Mirror operation: S=-C, so C+S=0.
This is a computational analogy, not a biological claim.
