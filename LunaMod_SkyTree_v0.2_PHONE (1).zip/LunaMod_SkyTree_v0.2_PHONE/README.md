# LunaMod — SkyTree v0.2 PHONE
Dependency-free single-page Android/Termux interface.

Run:
python3 -m http.server 8080
Then open http://127.0.0.1:8080

013 ABC mapping: A=0 OBSERVE, B=1 CREATE, C=3 VERIFY.
Protect and Explore are project principles, not supernatural mechanisms.
