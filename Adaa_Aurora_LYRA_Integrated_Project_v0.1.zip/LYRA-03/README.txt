LYRA-03 Dual-Channel Machine-Code Lab v0.2
Simulation only.

States:
0 = H 0V, M 0V = OFF/IDLE
1 = H 5V, M 0V = ONE
2 = H 0V, M 2.5V = TWO
3 = H 5V, M 2.5V = BOTH/JOIN

Important: 5V and 2.5V are independent simulated channels. The decoder adds their logical weights; it does NOT physically tie voltage rails together.

The chaos button injects temporary modeled voltage noise. Values outside tolerance are marked INVALID/HOLD rather than guessed.
