LYRA-05 — Paired Memory + Error Correction

Purpose:
Model two redundant logical memory layers, C and S, with verification and recovery.

Operations:
WRITE NEXT, SYNC PAIR, CORRUPT C, CORRUPT S, ERROR CORRECT, CHAOS BURST.

Safety/epistemic boundary:
C/S are computational labels. This is not a model of literal biological conscious/subconscious memory.

Recovery principle:
VERIFY -> ISOLATE -> COMPARE -> RESTORE -> VERIFY AGAIN.

The simulator intentionally refuses ambiguous correction instead of silently guessing.
