LUNAMOD — SKYTREE v0.1
Phone-ready offline web app.

FASTEST WAY ON ANDROID / TERMUX
1. Extract this folder to your phone.
2. In Termux, cd into LunaMod_SkyTree_v0.1.
3. Run: python3 -m http.server 8080
4. Open Chrome and visit: http://127.0.0.1:8080
5. Optional: use Chrome menu -> Add to Home screen.

It is intentionally an offline-first symbolic interface. The 013 ABC layer is software state logic, not a physical voltage law or supernatural mechanism.
